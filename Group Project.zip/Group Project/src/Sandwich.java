import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 *  Developer:  Nick Schneider, Chance Battles, Rachel Myers 
 */
public class Sandwich extends Application
{
    Scene sizeScene, breadScene,
          meatScene, cheeseScene,
          veggieScene, sauceScene,
          seasoningScene, finishOrderScene; 
    
    @Override
    public void start(Stage primaryStage)
    {
        
        //  Size of Sandwhich
        int sandwichSize;
        
        GridPane sizePane = new GridPane();
        sizePane.setHgap(10);
        sizePane.setVgap(2);
        
        ToggleGroup sizeGroup = new ToggleGroup();
        RadioButton rbSmall = new RadioButton("6 inch");
        RadioButton rbLarge = new RadioButton("Foot Long");
        
        rbSmall.setToggleGroup(sizeGroup);
        rbLarge.setToggleGroup(sizeGroup);
        
        sizePane.add(rbSmall, 0, 0);
        sizePane.add(rbLarge, 1, 0);
        
        Button btToBread = new Button("Next");
        btToBread.setOnAction(e ->primaryStage.setScene(breadScene));
        
        sizePane.add(btToBread, 2, 4);
        
        sizeScene = new Scene(sizePane, 555, 400); 
        
        // Breads
        GridPane breadPane = new GridPane();
        breadPane.setHgap(10);
        breadPane.setVgap(5);
        
        ToggleGroup breadGroup = new ToggleGroup();
        RadioButton rbItalianBread = new RadioButton("Italian");
        RadioButton rbWheatBread = new RadioButton("Wheat");
        RadioButton rbHerbCheese = new RadioButton("Italian Herb & Cheese");
        RadioButton rbJalapenoCheese = new RadioButton("Jalapeno & Cheese");
        RadioButton rbFlatbread = new RadioButton("Flatbread");
        
        rbItalianBread.setToggleGroup(breadGroup);
        rbWheatBread.setToggleGroup(breadGroup);
        rbHerbCheese.setToggleGroup(breadGroup);
        rbJalapenoCheese.setToggleGroup(breadGroup);
        rbFlatbread.setToggleGroup(breadGroup);
        
        breadPane.add(rbItalianBread, 0, 0);
        
        breadPane.add(rbWheatBread, 1, 0);
        
        breadPane.add(rbHerbCheese, 2, 0);
        
        breadPane.add(rbJalapenoCheese, 0, 2);
        
        breadPane.add(rbFlatbread, 1, 2);
        
        Button btToMeat= new Button("Next");
        btToMeat.setOnAction(e ->primaryStage.setScene(meatScene));
        
        breadPane.add(btToMeat, 2, 3);
        
        breadScene = new Scene(breadPane, 555, 400);
        
        
        //  Meats
        GridPane meatPane = new GridPane();
        meatPane.setHgap(10);
        meatPane.setVgap(50);
        
        ToggleGroup meatGroup = new ToggleGroup();        
        RadioButton rbBacon = new RadioButton("Bacon");  
        RadioButton rbHam = new RadioButton("Black Forest Ham");
        RadioButton rbChicken = new RadioButton("Chicken Strips");
        RadioButton rbSalami = new RadioButton("Genoa Salami");
        RadioButton rbPepperoni = new RadioButton("Pepperoni");
        RadioButton rbSteak = new RadioButton("Shaved Steak");
        
        rbBacon.setToggleGroup(meatGroup);
        rbHam.setToggleGroup(meatGroup);
        rbChicken.setToggleGroup(meatGroup);
        rbSalami.setToggleGroup(meatGroup);
        rbPepperoni.setToggleGroup(meatGroup);
        rbSteak.setToggleGroup(meatGroup);   
        
        
        meatPane.add(rbBacon, 0, 1);
        
        meatPane.add(rbHam, 1, 1);
        
        meatPane.add(rbChicken, 2, 1);
        
        meatPane.add(rbSalami, 0, 3);
        
        meatPane.add(rbPepperoni, 1, 3);
        
        meatPane.add(rbSteak, 2, 3); 
                        
        Button btToCheese= new Button("Next");
        btToCheese.setOnAction(e ->primaryStage.setScene(cheeseScene));
        
        meatPane.add(btToCheese, 2, 4);
        
        ScrollPane meatScrollPane = new ScrollPane(meatPane);
        
        meatScene = new Scene(meatScrollPane, 555, 400);   
        
        // Cheese
        GridPane cheesePane = new GridPane();
        cheesePane.setHgap(10);
        cheesePane.setVgap(5);
        
        ToggleGroup cheeseGroup = new ToggleGroup();
        RadioButton rbCheddar = new RadioButton("Cheddar");
        RadioButton rbPepperJack = new RadioButton("PepperJack");
        RadioButton rbProvolone = new RadioButton("Provolone");
        RadioButton rbMozzarella = new RadioButton("Mozzarella");
        RadioButton rbAmerican = new RadioButton("American");
        
        rbCheddar.setToggleGroup(cheeseGroup);
        rbPepperJack.setToggleGroup(cheeseGroup);
        rbProvolone.setToggleGroup(cheeseGroup);
        rbMozzarella.setToggleGroup(cheeseGroup);
        rbAmerican.setToggleGroup(cheeseGroup);
        
        cheesePane.add(rbCheddar, 0, 0);
        
        cheesePane.add(rbPepperJack, 1, 0);
        
        cheesePane.add(rbProvolone, 2, 0);
        
        cheesePane.add(rbMozzarella, 0, 1);
        
        cheesePane.add(rbAmerican, 1, 1);
        
        
        Button btToVeggies = new Button("Next");
        btToVeggies.setOnAction(e ->primaryStage.setScene(veggieScene));
        
        cheesePane.add(btToVeggies, 2,2);
        
        cheeseScene = new Scene(cheesePane, 555, 400);
        
        // Veggies
        GridPane veggiePane = new GridPane();
        sizePane.setHgap(10);
        sizePane.setVgap(2);
        
        CheckBox cbBananaPeppers = new CheckBox("Banana Peppers");
        CheckBox cbBlackOlives = new CheckBox("Black Olives");
        CheckBox cbCucumbers = new CheckBox("Cucumbers");
        CheckBox cbGreenPeppers = new CheckBox("GreenPeppers");
        CheckBox cbJalapenos = new CheckBox("Jalapenos");
        CheckBox cbLettuce = new CheckBox("Lettuce");
        CheckBox cbPickles = new CheckBox("Pickles");
        CheckBox cbRedOnions = new CheckBox("RedOnions");
        CheckBox cbSpinach = new CheckBox("Spinach");        
        CheckBox cbTomatoes = new CheckBox("Tomatoes");
        
        veggiePane.add(cbBananaPeppers, 0, 0);
        
        veggiePane.add(cbBlackOlives, 1, 0);
        
        veggiePane.add(cbCucumbers, 2, 0);
        
        veggiePane.add(cbGreenPeppers, 0, 2);
        
        veggiePane.add(cbJalapenos, 1, 2);
        
        veggiePane.add(cbLettuce, 2, 2);
        
        veggiePane.add(cbPickles, 0, 4);
        
        veggiePane.add(cbRedOnions, 1, 4);
        
        veggiePane.add(cbSpinach, 2, 4);
        
        veggiePane.add(cbTomatoes, 0, 6);
        
        
        Button btToSauces = new Button("Next");
        btToSauces.setOnAction(e ->primaryStage.setScene(sauceScene));
        
        veggiePane.add(btToSauces, 2, 7);
        
        ScrollPane veggieScrollPane = new ScrollPane(veggiePane);
             
        veggieScene = new Scene(veggieScrollPane, 555, 400);
        
        // Sauces
        GridPane saucePane = new GridPane();
        saucePane.setHgap(10);
        saucePane.setVgap(2);
        ToggleGroup sauceGroup = new ToggleGroup(); 
        
        RadioButton rbBBQ = new RadioButton("BBQ");
        RadioButton rbChipotle = new RadioButton("Chipotle");
        RadioButton rbBrownMustard = new RadioButton("Brown Mustard");
        RadioButton rbHoneyMustard = new RadioButton("Honey Mustard");
        RadioButton rbMayonaise = new RadioButton("Mayonaise");
        RadioButton rbRanch = new RadioButton("Ranch");
        RadioButton rbSweetOnion = new RadioButton("Sweet Onion");
        RadioButton rbSriracha = new RadioButton("Sriracha");
        RadioButton rbYellowMustard = new RadioButton("Yellow Mustard");
        RadioButton rbCaesar = new RadioButton("Caesar");
        
        rbBBQ.setToggleGroup(sauceGroup);
        rbChipotle.setToggleGroup(sauceGroup);
        rbBrownMustard.setToggleGroup(sauceGroup);
        rbHoneyMustard.setToggleGroup(sauceGroup);
        rbMayonaise.setToggleGroup(sauceGroup);
        rbRanch.setToggleGroup(sauceGroup);
        rbSweetOnion.setToggleGroup(sauceGroup);
        rbSriracha.setToggleGroup(sauceGroup);
        rbYellowMustard.setToggleGroup(sauceGroup);
        rbCaesar.setToggleGroup(sauceGroup);

        
        saucePane.add(rbBBQ, 0, 1);
        
        saucePane.add(rbChipotle, 1, 1);
        
        saucePane.add(rbBrownMustard, 2, 1);
        
        saucePane.add(rbHoneyMustard, 0, 3);
       
        saucePane.add(rbMayonaise, 1, 3);
        
        saucePane.add(rbRanch, 2, 3);
        
        saucePane.add(rbSweetOnion, 0, 5);
        
        saucePane.add(rbSriracha, 1, 5);
        
        saucePane.add(rbYellowMustard, 2, 5);
        
        saucePane.add(rbCaesar, 0, 7);
        
        Button btToSeasonings = new Button("Next");
        btToSeasonings.setOnAction(e ->primaryStage.setScene(seasoningScene));
        
        saucePane.add(btToSeasonings, 2, 8);
        
        ScrollPane sauceScrollPane = new ScrollPane(saucePane);
        
        sauceScene = new Scene(sauceScrollPane, 555, 400);        
                
        // Seasonings
        GridPane seasoningPane = new GridPane();
        seasoningPane.setHgap(10);
        seasoningPane.setVgap(5);
        
        Text tf = new Text("Would you Like Salt and Pepper?");
        
        RadioButton rbYes = new RadioButton("Yes");
        RadioButton rbNo = new RadioButton("No");
        
        ToggleGroup seasoningGroup = new ToggleGroup();
        rbYes.setToggleGroup(seasoningGroup);
        rbNo.setToggleGroup(seasoningGroup);
        
        seasoningPane.add(tf, 0, 0);
        seasoningPane.add(rbYes, 1, 2);
        seasoningPane.add(rbNo, 2, 2);
        
        Button btToFinishOrder = new Button("Next");
        btToFinishOrder.setOnAction(e ->primaryStage.setScene(finishOrderScene));
        
        seasoningPane.add(btToFinishOrder, 2, 4);
        
        seasoningScene = new Scene(seasoningPane, 555, 400);
        
        // Preview Order
        Pane pane = new Pane();
        TextArea ta = new TextArea();
        
        pane.getChildren().add(ta);
        
        // set stage        
        primaryStage.setTitle("Sandwich Ordering System");
        primaryStage.setScene(sizeScene);
        primaryStage.show();
    }
    
    public static void main(String[] args) 
    {
        launch(args);
    }
    
}
