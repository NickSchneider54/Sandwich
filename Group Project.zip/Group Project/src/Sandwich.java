import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 *  Developer:  Nick Schneider, Chance Battles, Rachel Myers 
 */
public class Sandwich extends Application
{
    Stage window;
    Scene sizeScene, meatScene,
          veggieScene, sauceScene,
          seasoningScene; 
    
    @Override
    public void start(Stage primaryStage)
    {
        
        //  Size of Sandwhich
        int sandwichSize;
        
        GridPane sizePane = new GridPane();
        sizePane.setHgap(10);
        sizePane.setVgap(2);
        
        ToggleGroup sizeGroup = new ToggleGroup();
        RadioButton rbSmall = new RadioButton("6 inch");
        RadioButton rbLarge = new RadioButton("Foot Long");
        
        rbSmall.setToggleGroup(sizeGroup);
        rbLarge.setToggleGroup(sizeGroup);
        
        sizePane.add(rbSmall, 0, 0);
        sizePane.add(rbLarge, 1, 0);
        
        Button btToMeats = new Button("Next");
        btToMeats.setOnAction(e ->primaryStage.setScene(meatScene));
        
        sizePane.add(btToMeats, 2, 4);
        
        sizeScene = new Scene(sizePane, 555, 400);                
        
        //  Meats
        GridPane meatPane = new GridPane();
        meatPane.setHgap(10);
        meatPane.setVgap(50);
        
        ToggleGroup meatGroup = new ToggleGroup();        
        RadioButton rbBacon = new RadioButton("Bacon");  
        RadioButton rbHam = new RadioButton("Black Forest Ham");
        RadioButton rbChicken = new RadioButton("Chicken Strips");
        RadioButton rbSalami = new RadioButton("Genoa Salami");
        RadioButton rbPepperoni = new RadioButton("Pepperoni");
        RadioButton rbSteak = new RadioButton("Shaved Steak");
        
        rbBacon.setToggleGroup(meatGroup);
        rbHam.setToggleGroup(meatGroup);
        rbChicken.setToggleGroup(meatGroup);
        rbSalami.setToggleGroup(meatGroup);
        rbPepperoni.setToggleGroup(meatGroup);
        rbSteak.setToggleGroup(meatGroup);   
        
        meatPane.add(new ImageView("Images/bacon.png"), 0, 0);
        meatPane.add(rbBacon, 0, 1);
        meatPane.add(new ImageView("Images/blackForestHam.png"), 1, 0);
        meatPane.add(rbHam, 1, 1);
        meatPane.add(new ImageView("Images/chickenStrips.png"), 2, 0);
        meatPane.add(rbChicken, 2, 1);
        meatPane.add(new ImageView("Images/genoaSalami.png"), 0, 2);
        meatPane.add(rbSalami, 0, 3);
        meatPane.add(new ImageView("Images/pepperoni.png"), 1, 2);
        meatPane.add(rbPepperoni, 1, 3);
        meatPane.add(new ImageView("Images/steak.png"), 2, 2);
        meatPane.add(rbSteak, 2, 3); 
                        
        Button btToVeggies = new Button("Next");
        btToVeggies.setOnAction(e ->primaryStage.setScene(veggieScene));
        
        meatPane.add(btToVeggies, 2, 4);
        
        ScrollPane meatScrollPane = new ScrollPane(meatPane);
        
        meatScene = new Scene(meatScrollPane, 560, 400);              
        
        // Veggies
        GridPane veggiePane = new GridPane();
        sizePane.setHgap(10);
        sizePane.setVgap(2);
        ToggleGroup veggieGroup = new ToggleGroup();  
        
        CheckBox cbBananaPeppers = new CheckBox("Banana Peppers");
        CheckBox cbBlackOlives = new CheckBox("Black Olives");
        CheckBox cbCucumbers = new CheckBox("Cucumbers");
        CheckBox cbGreenPeppers = new CheckBox("GreenPeppers");
        CheckBox cbJalapenos = new CheckBox("Jalapenos");
        CheckBox cbLettuce = new CheckBox("Lettuce");
        CheckBox cbPickles = new CheckBox("Pickles");
        CheckBox cbRedOnions = new CheckBox("RedOnions");
        CheckBox cbSpinach = new CheckBox("Spinach");        
        CheckBox cbTomatoes = new CheckBox("Tomatoes");
        
        veggiePane.add(cbBananaPeppers, 0, 0);
        veggiePane.add(new ImageView("Images/bananaPepper.png"), 0, 1);
        veggiePane.add(cbBlackOlives, 1, 0);
        veggiePane.add(new ImageView("Images/blackOlive.png"), 1, 1);
        veggiePane.add(cbCucumbers, 2, 0);
        veggiePane.add(new ImageView("Images/cucumber.png"), 2, 1);
        veggiePane.add(cbGreenPeppers, 0, 2);
        veggiePane.add(new ImageView("Images/greenPepper.png"), 0, 3);
        veggiePane.add(cbJalapenos, 1, 2);
        veggiePane.add(new ImageView("Images/jalapenos.png"), 1, 3);
        veggiePane.add(cbLettuce, 2, 2);
        veggiePane.add(new ImageView("Images/lettuce.png"), 2, 3);
        veggiePane.add(cbPickles, 0, 4);
        veggiePane.add(new ImageView("Images/pickles.png"), 0, 5);
        veggiePane.add(cbRedOnions, 1, 4);
        veggiePane.add(new ImageView("Images/redOnion.png"), 1, 5);
        veggiePane.add(cbSpinach, 2, 4);
        veggiePane.add(new ImageView("Images/spinach.png"), 2, 5);
        veggiePane.add(cbTomatoes, 0, 6);
        veggiePane.add(new ImageView("Images/tomatoe.png"), 0, 7);
        
        Button btToSauces = new Button("Next");
        btToSauces.setOnAction(e ->primaryStage.setScene(sauceScene));
        
        veggiePane.add(btToSauces, 2, 4);
        
        ScrollPane veggieScrollPane = new ScrollPane(veggiePane);
             
        veggieScene = new Scene(veggieScrollPane, 555, 400);
        
        // Sauces
        GridPane saucePane = new GridPane();
        saucePane.setHgap(10);
        saucePane.setVgap(2);
        ToggleGroup sauceGroup = new ToggleGroup(); 
        
        RadioButton rbBBQ = new RadioButton("BBQ");
        RadioButton rbChipotle = new RadioButton("Chipotle");
        RadioButton rbBrownMustard = new RadioButton("Brown Mustard");
        RadioButton rbHoneyMustard = new RadioButton("Honey Mustard");
        RadioButton rbMayonaise = new RadioButton("Mayonaise");
        RadioButton rbRanch = new RadioButton("Ranch");
        RadioButton rbSweetOnion = new RadioButton("Sweet Onion");
        RadioButton rbSriracha = new RadioButton("Sriracha");
        RadioButton rbYellowMustard = new RadioButton("Yellow Mustard");
        RadioButton rbCaesar = new RadioButton("Caesar");
        
        rbBBQ.setToggleGroup(sauceGroup);
        rbChipotle.setToggleGroup(sauceGroup);
        rbBrownMustard.setToggleGroup(sauceGroup);
        rbHoneyMustard.setToggleGroup(sauceGroup);
        rbMayonaise.setToggleGroup(sauceGroup);
        rbRanch.setToggleGroup(sauceGroup);
        rbSweetOnion.setToggleGroup(sauceGroup);
        rbSriracha.setToggleGroup(sauceGroup);
        rbYellowMustard.setToggleGroup(sauceGroup);
        rbCaesar.setToggleGroup(sauceGroup);

        saucePane.add(new ImageView("Images/bbq.png"), 0, 0);
        saucePane.add(rbBBQ, 0, 1);
        saucePane.add(new ImageView("Images/chipotle.png"), 1, 0);
        saucePane.add(rbChipotle, 1, 1);
        saucePane.add(new ImageView("Images/brwonMustard.png"), 2, 0);
        saucePane.add(rbBrownMustard, 2, 1);
        saucePane.add(new ImageView("Images/honeyMustard.png"), 0, 2);
        saucePane.add(rbHoneyMustard, 0, 3);
        saucePane.add(new ImageView("Images/mayonaise.png"), 1, 2);
        saucePane.add(rbMayonaise, 1, 3);
        saucePane.add(new ImageView("Images/ranch.png"), 2, 2);
        saucePane.add(rbRanch, 2, 3);
        saucePane.add(new ImageView("Images/sweetOnion.png"), 0, 4);
        saucePane.add(rbSweetOnion, 0, 5);
        saucePane.add(new ImageView("Images/sriracha.png"), 1, 4);
        saucePane.add(rbSriracha, 1, 5);
        saucePane.add(new ImageView("Images/yellowMustard.png"), 2, 4);
        saucePane.add(rbYellowMustard, 2, 5);
        saucePane.add(new ImageView("Images/caesar.png"), 0, 6);
        saucePane.add(rbCaesar, 0, 7);
        
        Button btToSeasonings = new Button("Next");
        btToSeasonings.setOnAction(e ->primaryStage.setScene(seasoningScene));
        
        saucePane.add(btToSeasonings, 2, 7);
        
        ScrollPane sauceScrollPane = new ScrollPane(saucePane);
        
        sauceScene = new Scene(sauceScrollPane, 550, 400);        
                
        // Seasonings
        GridPane seasoningPane = new GridPane();
        seasoningPane.setHgap(10);
        seasoningPane.setVgap(5);
        
        Text tf = new Text("Would you Like Salt and Pepper?");
        
        RadioButton rbYes = new RadioButton("Yes");
        RadioButton rbNo = new RadioButton("No");
        
        ToggleGroup seasoningGroup = new ToggleGroup();
        rbYes.setToggleGroup(seasoningGroup);
        rbNo.setToggleGroup(seasoningGroup);
        
        seasoningPane.add(tf, 0, 0);
        seasoningPane.add(rbYes, 1, 2);
        seasoningPane.add(rbNo, 2, 2);
        
        seasoningScene = new Scene(seasoningPane);
        
        // set stage        
        primaryStage.setTitle("Sandwich Size");
        primaryStage.setScene(sizeScene);
        primaryStage.show();
    }
    
    public static void main(String[] args) 
    {
        launch(args);
    }
    
}
